
package com210_lab1_q3;
import java.util.Scanner;

public class COM210_Lab1_Q3 {

    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    Scanner s = new Scanner(System.in);
    int aa;
    
    System.out.println("Enter the number of items");
    aa = s.nextInt();
    
    String[] items = new String[aa];
    double[] prices = new double[aa];
    int count = 0;

    while (count < items.length) {
      System.out.print("Enter item name: ");
      items[count] = input.nextLine();
      System.out.print("Enter item price: ");
      prices[count] = input.nextDouble();
      input.nextLine();
      count++;
    } 
    input.close();

    for (int i = items.length - 1; i >= 0; i--) { //prints in reverse order
      System.out.println(items[i] + ": " + prices[i]);
    }

    boolean peas = false;
    double sum = 0;

    for (int i = 0; i < items.length; i++) {
      if (items[i].equalsIgnoreCase("peas")) {
        peas = true;
        sum += prices[i];
      }
      if (peas) {
      System.out.println("The average price is: " + (sum / items.length));
      } else {
      System.out.println("no average output");
    }
    }

    }
    
}
